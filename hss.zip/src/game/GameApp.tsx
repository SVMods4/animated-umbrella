import { useEffect, useRef } from "react";
import {
  ArrowDown,
  BookOpen,
  DoorOpen,
  Flashlight,
  Hand,
  Pause,
  Play,
  RotateCcw,
  Settings,
  Trophy,
} from "lucide-react";
import { ACHIEVEMENTS, NOTES } from "./data";
import { api, mountGame, unmountGame } from "./engine";
import { useGameUI } from "./store";

function Panel({
  children,
  wide,
}: {
  children: React.ReactNode;
  wide?: boolean;
}) {
  return (
    <div
      className={
        "pointer-events-auto max-h-[min(88dvh,720px)] overflow-y-auto border border-border bg-surface/95 px-6 py-6 text-center shadow-[0_24px_60px_rgba(0,0,0,0.55)] " +
        (wide ? "w-[min(440px,92vw)] rounded-xl" : "w-[min(360px,92vw)] rounded-lg")
      }
      style={{ paddingBottom: "max(1.5rem, env(safe-area-inset-bottom))" }}
    >
      {children}
    </div>
  );
}

function Btn({
  children,
  onClick,
  primary,
  danger,
}: {
  children: React.ReactNode;
  onClick: () => void;
  primary?: boolean;
  danger?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={
        "mt-2 inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-sm border px-4 py-2.5 font-display text-[15px] tracking-wide text-fg transition-transform duration-[var(--motion-quick)] ease-[var(--ease-out)] active:scale-[0.98] " +
        (primary
          ? "border-primary bg-primary/20 text-fg"
          : danger
            ? "border-danger/70 bg-danger/10"
            : "border-border bg-elevated")
      }
    >
      {children}
    </button>
  );
}

function Range({
  label,
  value,
  min,
  max,
  step,
  onChange,
  display,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (v: number) => void;
  display: string;
}) {
  return (
    <label className="mt-3 block text-left text-sm text-muted">
      <span className="flex justify-between">
        <span>{label}</span>
        <span className="tabular-nums text-accent">{display}</span>
      </span>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(+e.target.value)}
        className="mt-1 w-full accent-primary"
      />
    </label>
  );
}

function SettingsBody({ back }: { back: () => void }) {
  const s = useGameUI();
  return (
    <>
      <h2 className="font-display text-xl text-primary">Настройки</h2>
      <Range
        label="Яркость"
        value={s.brightness}
        min={0.7}
        max={1.8}
        step={0.05}
        display={s.brightness.toFixed(2)}
        onChange={api.setBright}
      />
      <Range
        label="Чувствительность"
        value={s.sens}
        min={0.5}
        max={1.8}
        step={0.05}
        display={s.sens.toFixed(2)}
        onChange={api.setSens}
      />
      <Range
        label="Громкость"
        value={s.volume}
        min={0}
        max={1}
        step={0.05}
        display={`${Math.round(s.volume * 100)}%`}
        onChange={api.setVol}
      />
      <label className="mt-3 block text-left text-sm text-muted">
        Сложность
        <select
          className="mt-1 w-full rounded-sm border border-border bg-elevated px-3 py-2 text-fg"
          value={String(s.difficulty)}
          onChange={(e) => api.setDiff(+e.target.value)}
        >
          <option value="0.7">Лёгкая</option>
          <option value="1">Нормальная</option>
          <option value="1.35">Сложная</option>
        </select>
      </label>
      <div className="mt-4">
        <Btn onClick={back}>Закрыть</Btn>
        <Btn danger onClick={api.resetSave}>
          Сброс сохранения
        </Btn>
      </div>
    </>
  );
}

function Overlay() {
  const s = useGameUI();

  if (s.screen === "play") return null;

  const winCopy =
    s.winKind === "outdoors"
      ? "Ты прошёл парк и вышел к людям."
      : s.winKind === "rooms"
        ? "Пять светлых комнат. Театр не достал тебя."
        : "Генератор запущен. Часть зала снова видит свет.";

  return (
    <div className="pointer-events-none absolute inset-0 z-30 flex items-center justify-center bg-[radial-gradient(ellipse_at_center,rgba(26,14,10,0.55),rgba(8,4,4,0.88))] p-4">
      {s.screen === "title" && (
        <Panel>
          <p className="text-[11px] tracking-[0.28em] text-muted uppercase">театр «Этерния»</p>
          <h1 className="mt-1 font-display text-[clamp(2.4rem,11vw,3.6rem)] leading-none text-primary">
            ТЕАТР ТЕНЕЙ
          </h1>
          <p className="mt-3 text-sm leading-snug text-muted">
            Спектакль «Последний зритель» не закончился.
            <br />
            Сорок дверей. Три пути наружу.
          </p>
          <div className="mt-5">
            <Btn primary onClick={() => api.start(false)}>
              <DoorOpen className="size-4" /> Войти
            </Btn>
            {s.hasSave && (
              <Btn onClick={() => api.start(true)}>
                <Play className="size-4" /> Продолжить
              </Btn>
            )}
            <Btn onClick={() => api.open("settings")}>
              <Settings className="size-4" /> Настройки
            </Btn>
            <Btn onClick={() => api.open("help")}>Как играть</Btn>
            <Btn onClick={() => api.open("achievements")}>
              <Trophy className="size-4" /> Достижения
            </Btn>
          </div>
          <p className="mt-4 text-[11px] text-subtle">шрифт Doors Cyrillic · NiceClub95</p>
        </Panel>
      )}

      {s.screen === "settings" && (
        <Panel>
          <SettingsBody back={() => api.resume()} />
        </Panel>
      )}

      {s.screen === "help" && (
        <Panel>
          <h2 className="font-display text-xl text-primary">Как играть</h2>
          <ul className="mt-3 space-y-2 text-left text-sm leading-snug text-muted">
            <li>Джойстик или WASD — движение.</li>
            <li>Фонарик — свет, но батарея садится.</li>
            <li>Действие — двери, прятки, предметы.</li>
            <li>Присесть — тише и уже.</li>
            <li>Лом в подсобке открывает люк в парк.</li>
            <li>Мигают лампы — прячься от Бладзы.</li>
            <li>Чёрная жижа — беги вперёд, обходи люстры.</li>
            <li>В парке прячься от Xillie в будках.</li>
          </ul>
          <Btn onClick={() => api.open("title")}>Назад</Btn>
        </Panel>
      )}

      {s.screen === "achievements" && (
        <Panel wide>
          <h2 className="font-display text-xl text-primary">Достижения</h2>
          <ul className="mt-3 space-y-2 text-left">
            {ACHIEVEMENTS.map((a) => {
              const got = s.achievements.includes(a.id);
              return (
                <li
                  key={a.id}
                  className={
                    "rounded-sm border px-3 py-2 " +
                    (got ? "border-accent/40 bg-elevated text-fg" : "border-border/60 text-subtle")
                  }
                >
                  <div className="text-sm">{got ? a.title : "????"}</div>
                  <div className="text-[11px] text-muted">{a.hint}</div>
                </li>
              );
            })}
          </ul>
          <Btn onClick={() => api.open("title")}>Назад</Btn>
        </Panel>
      )}

      {s.screen === "note" && (
        <Panel>
          <p className="text-[11px] tracking-widest text-muted">ЗАПИСКА</p>
          <h2 className="mt-1 font-display text-lg text-accent">{s.noteTitle}</h2>
          <p className="mt-3 whitespace-pre-wrap text-left text-sm leading-relaxed text-fg">{s.noteText}</p>
          <Btn onClick={api.closeNote}>Закрыть</Btn>
        </Panel>
      )}

      {s.screen === "pause" && (
        <Panel>
          <h2 className="font-display text-xl text-primary">Пауза</h2>
          <p className="mt-1 text-sm text-muted">{s.zoneTitle}</p>
          <Btn primary onClick={api.resume}>
            Продолжить
          </Btn>
          <Btn onClick={() => api.open("journal")}>
            <BookOpen className="size-4" /> Журнал записок
          </Btn>
          <Btn onClick={() => api.open("settings")}>
            <Settings className="size-4" /> Настройки
          </Btn>
          <Btn onClick={api.toTitle}>В меню</Btn>
        </Panel>
      )}

      {s.screen === "journal" && (
        <Panel wide>
          <h2 className="font-display text-xl text-primary">Журнал</h2>
          <p className="mt-1 text-xs text-muted">
            {s.notesFound.length} / {NOTES.length}
          </p>
          <ul className="mt-3 max-h-72 space-y-2 overflow-y-auto text-left">
            {NOTES.filter((n) => s.notesFound.includes(n.id)).map((n) => (
              <li key={n.id} className="rounded-sm border border-border bg-elevated px-3 py-2">
                <div className="text-sm text-accent">{n.title}</div>
                <div className="mt-1 text-xs leading-snug text-muted">{n.text}</div>
              </li>
            ))}
            {s.notesFound.length === 0 && <li className="text-sm text-subtle">Пока пусто.</li>}
          </ul>
          <Btn onClick={() => api.open("pause")}>Назад</Btn>
        </Panel>
      )}

      {s.screen === "dead" && (
        <Panel>
          <h1 className="font-display text-4xl text-primary">ТЫ ПАЛ</h1>
          <p className="mt-3 text-sm text-muted">Тьма театра поглотила тебя.</p>
          <Btn primary onClick={() => api.start(false)}>
            <RotateCcw className="size-4" /> Начать снова
          </Btn>
          <Btn onClick={api.toTitle}>В меню</Btn>
        </Panel>
      )}

      {s.screen === "win" && (
        <Panel>
          <h1 className="font-display text-4xl text-ok">ВЫХОД</h1>
          <p className="mt-3 text-sm leading-snug text-muted">{winCopy}</p>
          <Btn primary onClick={api.showCredits}>
            Титры
          </Btn>
          <Btn onClick={() => api.start(false)}>Ещё раз</Btn>
          <Btn onClick={api.toTitle}>В меню</Btn>
        </Panel>
      )}

      {s.screen === "credits" && (
        <Panel wide>
          <div className="space-y-3 text-sm leading-relaxed text-muted">
            {s.creditsLines.map((line, i) =>
              line === "" ? (
                <div key={i} className="h-2" />
              ) : (
                <p key={i} className={i === 0 ? "font-display text-2xl text-primary" : ""}>
                  {line}
                </p>
              ),
            )}
          </div>
          <Btn onClick={api.toTitle}>В меню</Btn>
        </Panel>
      )}
    </div>
  );
}

function Hud() {
  const s = useGameUI();
  if (s.screen !== "play") return null;
  return (
    <div
      className="pointer-events-none absolute inset-x-0 top-0 z-20 flex items-start justify-between gap-2 p-2.5"
      style={{ paddingTop: "max(10px, env(safe-area-inset-top))" }}
    >
      <div className="flex flex-wrap gap-1.5">
        <Chip label="Здоровье">
          <Bar pct={s.health} tone="health" />
        </Chip>
        <Chip label="Комната">
          <div className="tabular-nums text-xs text-fg">{s.roomLabel}</div>
        </Chip>
        <Chip label="Фонарик">
          <Bar pct={s.battery} tone="battery" />
        </Chip>
        {s.hasCrowbar && <Chip label="Лом">есть</Chip>}
        {s.hasKey && <Chip label="Ключ">есть</Chip>}
        {s.techBatteries > 0 && <Chip label="Энергия">{s.techBatteries}/15</Chip>}
      </div>
      <button
        type="button"
        className="pointer-events-auto flex size-10 items-center justify-center rounded-sm border border-border bg-bg/80 text-accent"
        onClick={api.pause}
        aria-label="Пауза"
      >
        <Pause className="size-4" />
      </button>
    </div>
  );
}

function Chip({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="rounded-sm border border-border bg-surface/92 px-2.5 py-1.5 shadow-[0_8px_18px_rgba(0,0,0,0.45)]">
      <div className="text-[9px] tracking-wide text-muted">{label}</div>
      {children}
    </div>
  );
}

function Bar({ pct, tone }: { pct: number; tone: "health" | "battery" }) {
  return (
    <div className="mt-0.5 h-1.5 w-20 overflow-hidden rounded-[2px] border border-border bg-elevated">
      <div
        className={"h-full " + (tone === "health" ? "bg-primary" : "bg-ok")}
        style={{ width: `${Math.max(0, Math.min(100, pct))}%` }}
      />
    </div>
  );
}

function Message() {
  const s = useGameUI();
  if (s.screen !== "play" || !s.message) return null;
  return (
    <div className="pointer-events-none absolute bottom-[168px] left-1/2 z-20 w-[min(88%,420px)] -translate-x-1/2 rounded-sm border border-border bg-bg/90 px-3 py-2 text-center text-sm text-fg">
      {s.message}
    </div>
  );
}

function Objective() {
  const s = useGameUI();
  if (s.screen !== "play") return null;
  return (
    <div className="pointer-events-none absolute left-1/2 top-14 z-10 w-[min(80%,360px)] -translate-x-1/2 text-center text-[11px] text-muted">
      {s.zoneTitle}
      <span className="mx-1 text-subtle">·</span>
      {s.objective}
    </div>
  );
}

function Controls() {
  const s = useGameUI();
  const base = useRef<HTMLDivElement>(null);
  const knob = useRef<HTMLDivElement>(null);
  const idRef = useRef<number | null>(null);

  useEffect(() => {
    const el = base.current;
    const k = knob.current;
    if (!el || !k) return;

    const setFrom = (cx: number, cy: number) => {
      const r = el.getBoundingClientRect();
      const x0 = r.left + r.width / 2;
      const y0 = r.top + r.height / 2;
      let dx = cx - x0;
      let dy = cy - y0;
      const max = 48;
      const len = Math.hypot(dx, dy);
      if (len > max) {
        dx = (dx / len) * max;
        dy = (dy / len) * max;
      }
      k.style.transform = `translate(calc(-50% + ${dx}px), calc(-50% + ${dy}px))`;
      // Deadzone inside stick itself
      const strength = len < 8 ? 0 : Math.min(1, len / max);
      const nx = len > 0.001 ? (dx / len) * strength : 0;
      const ny = len > 0.001 ? (dy / len) * strength : 0;
      api.setStick(nx, ny, true);
    };
    const end = () => {
      idRef.current = null;
      k.style.transform = "translate(-50%, -50%)";
      api.setStick(0, 0, false);
    };

    const onStart = (e: PointerEvent) => {
      e.preventDefault();
      e.stopPropagation();
      idRef.current = e.pointerId;
      try {
        el.setPointerCapture(e.pointerId);
      } catch {
        /* ignore */
      }
      setFrom(e.clientX, e.clientY);
    };
    const onMove = (e: PointerEvent) => {
      if (idRef.current !== e.pointerId) return;
      e.preventDefault();
      setFrom(e.clientX, e.clientY);
    };
    const onEnd = (e: PointerEvent) => {
      if (idRef.current !== null && idRef.current !== e.pointerId) return;
      end();
    };
    el.addEventListener("pointerdown", onStart, { passive: false });
    el.addEventListener("pointermove", onMove, { passive: false });
    el.addEventListener("pointerup", onEnd);
    el.addEventListener("pointercancel", onEnd);
    el.addEventListener("lostpointercapture", onEnd);
    return () => {
      el.removeEventListener("pointerdown", onStart);
      el.removeEventListener("pointermove", onMove);
      el.removeEventListener("pointerup", onEnd);
      el.removeEventListener("pointercancel", onEnd);
      el.removeEventListener("lostpointercapture", onEnd);
      api.setStick(0, 0, false);
    };
  }, []);

  if (s.screen !== "play") return null;

  return (
    <div
      className="pointer-events-none absolute inset-x-0 bottom-0 z-20 h-[155px]"
      style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
    >
      <div
        ref={base}
        className="pointer-events-auto absolute bottom-4 left-4 size-[140px] rounded-full border-2 border-border/60 bg-elevated/55 touch-none"
        style={{ touchAction: "none" }}
      >
        <div
          ref={knob}
          className="absolute left-1/2 top-1/2 size-14 -translate-x-1/2 -translate-y-1/2 rounded-full border-2 border-accent bg-[radial-gradient(circle_at_35%_35%,#c09060,#5a3018)] pointer-events-none"
        />
      </div>
      <Ctrl
        className="bottom-20 right-4"
        label="Фонарик"
        active={s.flashlight}
        onPress={api.flash}
      >
        <Flashlight className="size-5" />
      </Ctrl>
      <Ctrl className="bottom-4 right-4" label="Действие" onPress={api.interact}>
        <Hand className="size-5" />
      </Ctrl>
      <Ctrl
        className="bottom-4 right-[84px]"
        label="Присесть"
        active={s.crouch}
        onPress={api.crouch}
      >
        <ArrowDown className="size-5" />
      </Ctrl>
    </div>
  );
}

function Ctrl({
  className,
  label,
  children,
  onPress,
  active,
}: {
  className: string;
  label: string;
  children: React.ReactNode;
  onPress: () => void;
  active?: boolean;
}) {
  return (
    <button
      type="button"
      aria-label={label}
      onPointerDown={(e) => {
        e.preventDefault();
        onPress();
      }}
      className={
        "pointer-events-auto absolute flex size-14 items-center justify-center rounded-full border-2 text-fg " +
        (active ? "border-accent bg-accent/25" : "border-border bg-elevated/80") +
        " " +
        className
      }
    >
      {children}
    </button>
  );
}

export function GameApp() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const c = canvasRef.current;
    if (!c) return;
    mountGame(c);
    return () => unmountGame();
  }, []);

  return (
    <main className="relative h-dvh w-full overflow-hidden bg-bg text-fg">
      <canvas ref={canvasRef} className="block h-full w-full bg-bg" />
      <Hud />
      <Objective />
      <Message />
      <Controls />
      <Overlay />
    </main>
  );
}
